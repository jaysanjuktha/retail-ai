# AI Commerce Intelligence Platform for Modern Retail Systems

Special Project (Phase 2), Dept. of CSE, IFHE Hyderabad.

A web dashboard that gives a retail store owner:
- **Revenue forecast** for the next 30 days (Linear Regression)
- **Customer segments**: Champions, Regular, At risk (K-Means on RFM)
- **Product recommendations** (market basket / co-occurrence)
- **Ask your data** in plain language

## Run in GitHub (Codespaces)
1. Push this folder to a GitHub repository.
2. Click **Code > Codespaces > Create codespace on main**.
3. Wait for setup. The app starts by itself and the dashboard opens in a browser tab.
   If it does not, open the **Ports** tab and click the globe icon next to port 5000.

## Run on your computer
```bash
cd backend
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Structure
```
backend/    Flask API + ML models (app.py)
frontend/   Dashboard (index.html)
docs/       Problem statement and video scripts
.devcontainer/  One-click Codespaces setup
```

## API
| Endpoint | Purpose |
|---|---|
| GET /api/kpis | Headline numbers |
| GET /api/forecast | 60-day history + 30-day forecast |
| GET /api/segments | Customer segments |
| GET /api/recommend?product=Tea | Bought-together products |
| POST /api/ask | Plain-language questions |

Note: the prototype uses synthetic sample data. GitHub Pages cannot run the Flask backend, so use Codespaces or run locally.
