"""AI Commerce Intelligence Platform - backend (Flask).
Run:  pip install -r requirements.txt
      python app.py        ->  http://127.0.0.1:5000
Uses synthetic retail data so the demo works without a database."""
from collections import Counter
from itertools import combinations

import numpy as np
import pandas as pd
from flask import Flask, jsonify, request, send_from_directory
from sklearn.cluster import KMeans
from sklearn.linear_model import LinearRegression

app = Flask(__name__, static_folder="../frontend", static_url_path="")


@app.after_request
def allow_frontend(resp):  # lets index.html call the API from any origin
    resp.headers["Access-Control-Allow-Origin"] = "*"
    return resp


# ---------- 1. Synthetic data ----------
rng = np.random.default_rng(42)
PRODUCTS = {"Milk": 30, "Bread": 25, "Rice": 60, "Eggs": 8, "Butter": 55,
            "Tea": 120, "Biscuits": 20, "Soap": 35, "Shampoo": 90, "Noodles": 15}

days = pd.date_range(end=pd.Timestamp.today().normalize(), periods=365)
t = np.arange(len(days))
daily = pd.DataFrame({"date": days})
for name, price in PRODUCTS.items():
    base = rng.integers(40, 120)
    units = base + 0.08 * t + 12 * (days.dayofweek >= 5) + rng.normal(0, 8, len(t))
    daily[name] = np.clip(units, 0, None).round()
daily["revenue"] = sum(daily[p] * pr for p, pr in PRODUCTS.items())

customers = pd.DataFrame({
    "id": range(1, 301),
    "recency": rng.integers(1, 180, 300),
    "frequency": rng.integers(1, 40, 300),
    "monetary": rng.integers(500, 50000, 300),
})
baskets = [set(rng.choice(list(PRODUCTS), rng.integers(2, 5), replace=False)) for _ in range(2000)]
pair_counts = Counter()
for b in baskets:
    for a, c in combinations(sorted(b), 2):
        pair_counts[(a, c)] += 1
        pair_counts[(c, a)] += 1


# ---------- 2. Models ----------
def forecast_revenue(horizon=30):
    """Linear trend + day-of-week effect -> next `horizon` days of revenue."""
    def feats(dates, idx):
        dow = np.eye(7)[dates.dayofweek]
        return np.column_stack([idx, dow])
    model = LinearRegression().fit(feats(pd.DatetimeIndex(daily["date"]), t), daily["revenue"])
    fut = pd.date_range(daily["date"].iloc[-1] + pd.Timedelta(days=1), periods=horizon)
    pred = model.predict(feats(fut, np.arange(len(t), len(t) + horizon)))
    return fut, pred


def segment_customers():
    """K-Means on RFM -> Champions / Regular / At-risk."""
    X = customers[["recency", "frequency", "monetary"]]
    Xs = (X - X.mean()) / X.std()
    km = KMeans(n_clusters=3, n_init=10, random_state=1).fit(Xs)
    df = customers.assign(cluster=km.labels_)
    g = df.groupby("cluster")[["recency", "frequency", "monetary"]].mean()
    score = (-g["recency"].rank() + g["frequency"].rank() + g["monetary"].rank())
    order = score.sort_values(ascending=False).index.tolist()
    names = dict(zip(order, ["Champions", "Regular", "At risk"]))
    df["segment"] = df["cluster"].map(names)
    return df


SEG = segment_customers()


# ---------- 3. API ----------
@app.get("/")
def home():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/api/kpis")
def kpis():
    last30, prev30 = daily.tail(30), daily.iloc[-60:-30]
    top = {p: float(last30[p].sum() * PRODUCTS[p]) for p in PRODUCTS}
    growth = (last30["revenue"].sum() / prev30["revenue"].sum() - 1) * 100
    return jsonify(revenue_30d=round(float(last30["revenue"].sum())),
                   growth_pct=round(float(growth), 1),
                   customers=len(customers),
                   at_risk=int((SEG["segment"] == "At risk").sum()),
                   top_products=sorted(top.items(), key=lambda x: -x[1])[:5])


@app.get("/api/forecast")
def forecast():
    fut, pred = forecast_revenue(30)
    hist = daily.tail(60)
    return jsonify(history={"dates": hist["date"].dt.strftime("%d %b").tolist(),
                            "values": hist["revenue"].round().tolist()},
                   forecast={"dates": fut.strftime("%d %b").tolist(),
                             "values": [round(float(v)) for v in pred]})


@app.get("/api/segments")
def segments():
    g = SEG.groupby("segment").agg(count=("id", "count"), avg_spend=("monetary", "mean"))
    return jsonify([{"segment": s, "count": int(r["count"]), "avg_spend": round(float(r["avg_spend"]))}
                    for s, r in g.iterrows()])


@app.get("/api/recommend")
def recommend():
    item = request.args.get("product", "Milk")
    if item not in PRODUCTS:
        return jsonify(error="Unknown product"), 400
    scores = {b: n for (a, b), n in pair_counts.items() if a == item}
    top = sorted(scores.items(), key=lambda x: -x[1])[:3]
    return jsonify(product=item, suggestions=[{"product": p, "bought_together": n} for p, n in top])


@app.get("/api/products")
def products():
    return jsonify(list(PRODUCTS))


@app.post("/api/ask")
def ask():
    q = (request.json or {}).get("question", "").lower()
    if "forecast" in q or "next" in q:
        _, pred = forecast_revenue(7)
        return jsonify(answer=f"Expected revenue for the next 7 days is about Rs {round(float(pred.sum())):,}.")
    if "risk" in q or "churn" in q:
        n = int((SEG["segment"] == "At risk").sum())
        return jsonify(answer=f"{n} customers are at risk of leaving. A discount campaign is advised.")
    if "top" in q or "best" in q:
        top = kpis().json["top_products"][0]
        return jsonify(answer=f"{top[0]} is the best seller, with Rs {round(top[1]):,} in the last 30 days.")
    return jsonify(answer="Try asking about the forecast, top products, or customers at risk.")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
