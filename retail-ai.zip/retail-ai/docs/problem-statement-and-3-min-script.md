# AI Commerce Intelligence Platform for Modern Retail Systems

## Problem Statement
Modern retailers collect large volumes of sales and customer data, but most small and mid-sized stores still make decisions by instinct. This causes three recurring problems: stock is ordered without a reliable demand estimate, so shelves run empty or goods go unsold; customers who are about to stop buying are noticed too late; and staff have no data-driven way to suggest related products at the time of sale.

This project proposes an AI-based platform that turns routine retail data into clear decisions. It forecasts future revenue, groups customers into meaningful segments, recommends products that are frequently bought together, and answers business questions in plain language through a simple web dashboard.

**Objectives**
1. Forecast daily revenue for the next 30 days.
2. Segment customers using recency, frequency and monetary value (RFM).
3. Recommend related products using purchase-basket analysis.
4. Provide a single dashboard that a non-technical store owner can use.

**Scope:** a working prototype on synthetic retail data, with a Flask backend, machine-learning models (scikit-learn) and a browser-based frontend. Live POS integration is out of scope for this phase.

---

## Video Script (about 3 minutes)

**[0:00-0:20] Introduction** (face or title slide)
"Hello, I am Punjala Jay Sanjuktha, B.Tech CSE (AI and ML), IFHE Hyderabad. This is the working phase of my special project: the AI Commerce Intelligence Platform for Modern Retail Systems."

**[0:20-0:50] Problem** (slide with problem statement)
"Many retailers still decide stock and offers by guesswork. They run out of fast-selling items, lose customers without noticing, and miss chances to sell related products. My platform solves this using AI."

**[0:50-1:15] Architecture** (diagram: Frontend -> Flask API -> ML models -> Data)
"The system has three parts. A web dashboard built with HTML, JavaScript and Chart.js. A Flask backend that exposes REST APIs. And machine-learning models built with scikit-learn on retail data."

**[1:15-2:30] Live demo** (screen record the dashboard)
- "At the top are the key numbers: 30-day revenue, growth against the previous month, total customers, and customers at risk."
- "This chart shows the last 60 days of sales and a 30-day forecast. The model is linear regression with a trend and a day-of-week effect, so weekend peaks are captured."
- "Here, K-Means clustering splits customers into Champions, Regular and At risk using recency, frequency and spend. The store can target the at-risk group with offers."
- "I select Tea and click Get suggestions. The system shows products most often bought with it, found by counting co-occurrence in baskets."
- "Finally, I can ask in plain words: 'forecast for next week'. The platform replies with the expected revenue."

**[2:30-2:50] Results and next steps**
"The prototype now delivers forecasting, segmentation, recommendations and a question-answer interface. Next, I will connect real point-of-sale data and improve the forecast with seasonal models."

**[2:50-3:00] Close**
"Thank you."

**Recording tips:** run `python app.py` first, then open `index.html`; record with OBS or Windows Game Bar (Win+G); keep the browser zoom at 110%.
