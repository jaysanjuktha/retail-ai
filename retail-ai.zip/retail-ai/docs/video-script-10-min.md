# 10-Minute Video Script: AI Commerce Intelligence Platform

Speaking pace: about 130 words per minute. Text in quotes is what you say. Text in brackets is what is on screen.

---

## 0:00 - 0:45 | Introduction
[Title slide with project name, your name, IFHE, Dept. of CSE]

"Hello everyone. I am Punjala Jay Sanjuktha, a B.Tech CSE student specialising in AI and Machine Learning at ICFAI Foundation for Higher Education, Hyderabad, batch 2024 to 2028.

Today I will present the working phase of my Special Project, called the AI Commerce Intelligence Platform for Modern Retail Systems. In the next ten minutes I will explain the problem, my solution, how it is built, and then show it working live."

## 0:45 - 2:00 | Problem Statement
[Slide: three short problems]

"Every retail store, from a small supermarket to an online shop, collects sales data every day. But most of this data is never used. Owners decide by instinct, and this creates three problems.

First, stock planning. Without a reliable demand estimate, popular items run out and slow items stay unsold, which wastes money.

Second, customer loss. Customers who are slowly drifting away are noticed only after they have gone.

Third, missed sales. At the billing counter, nobody knows which product to suggest next.

So the core problem is this: retailers have data but no simple, intelligent tool to turn that data into decisions. My project builds that tool."

## 2:00 - 3:00 | Objectives and Scope
[Slide: four objectives]

"I set four objectives. One, forecast revenue for the next 30 days. Two, segment customers by their buying behaviour. Three, recommend products that are bought together. Four, give the store owner one simple dashboard, with no technical knowledge needed.

For this phase, the scope is a working prototype on realistic sample data. Connecting live billing systems is planned for the next phase."

## 3:00 - 4:30 | Architecture and Technology
[Diagram: Browser dashboard -> Flask REST API -> ML models -> Data]

"The system has three layers.

The top layer is the frontend. It is a web page built with HTML, CSS and JavaScript, and it draws charts using Chart.js.

The middle layer is the backend, built with Python and Flask. It exposes REST APIs, such as kpis, forecast, segments, recommend and ask. The frontend calls these APIs and shows the results.

The bottom layer is the intelligence. I use pandas and NumPy for data handling, and scikit-learn for machine learning.

I used three techniques. Linear Regression for forecasting. K-Means clustering for customer segmentation. And co-occurrence analysis, also called market basket analysis, for recommendations. I chose these because they are fast, explainable and suitable for small and medium retailers."

## 4:30 - 5:15 | Data
[Slide: data table preview]

"The prototype uses sample data that behaves like a real store: 365 days of sales for ten products, 300 customers with their recency, frequency and spending, and 2,000 shopping baskets. The sales data includes a rising trend and weekend peaks, just like real retail."

## 5:15 - 8:30 | Live Demo
[Switch to the browser. Backend already running.]

**Dashboard overview (5:15 - 6:00)**
"This is the dashboard. At the top are four key numbers: revenue in the last 30 days, growth compared to the previous 30 days, the number of customers, and how many customers are at risk. The owner understands the business health in one glance."

**Forecast (6:00 - 7:00)**
"This chart shows the last 60 days of actual sales in dark colour, and the next 30 days of forecast in the dotted green line. The model learns the overall trend and the day-of-week pattern, so you can see the forecast rises on weekends, as it did in the past. With this, the owner can plan stock for the coming month."

**Customer segments (7:00 - 7:40)**
"Here, K-Means clustering groups customers using recency, frequency and monetary value. We get three groups: Champions, who buy often and spend more; Regular customers; and At-risk customers, who have not visited recently. The store can reward Champions and send offers to the at-risk group before they leave."

**Recommendations (7:40 - 8:10)**
"Now I select Tea and click Get suggestions. The system shows the products most often bought with tea, along with how many times they were bought together. A cashier or an online shop can use this to suggest the next product."

**Ask your data (8:10 - 8:30)**
"Finally, I type: forecast for next week. The platform replies with the expected revenue. I can also ask about the top product or customers at risk. This lets a non-technical owner use the system in simple language."

## 8:30 - 9:15 | Results and Limitations
[Slide: results and limitations]

"The prototype now delivers all four objectives: forecasting, segmentation, recommendation and a question-answer interface, all in one dashboard.

There are limitations. The data is sample data, the forecast uses a simple model, and the question-answer feature works on keywords. These are the areas I will improve."

## 9:15 - 10:00 | Future Work and Conclusion
[Slide: future work, then thank-you slide]

"In the next phase, I plan to connect real point-of-sale data, use stronger forecasting models such as Prophet or LSTM, add stock alerts, and upgrade the question-answer feature with a language model.

To conclude, the AI Commerce Intelligence Platform shows how everyday retail data can become clear, useful decisions. Thank you for watching. I welcome your questions and feedback."

---

## Slides to Prepare (8 slides)
1. Title
2. Problem statement
3. Objectives and scope
4. Architecture diagram
5. Technology and models
6. Data used
7. Results and limitations
8. Future work and thank you

## Recording Checklist
- Start the backend first: `python app.py`, then open `index.html`
- Record with OBS, or Win+G on Windows, with your microphone on
- Set browser zoom to 110% and close other tabs
- Practise once with a timer; if you are over 10 minutes, shorten the data slide
